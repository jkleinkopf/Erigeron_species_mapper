# ggfun 0.2.2

+ add `geom_bezier()` and `GeomBezier` for drawing grouped cubic Bezier paths;
  this provides the low-level edge layer used by `ggtangle` to reproduce
  ggraph-compatible circular network arcs (2026-10-05, Mon)
+ remove `volplot()` and `geom_volpoint()`: volcano plotting now lives in the
  `ivolcano` package (2026-10-06, Tue)
+ `set_font()` is now implemented on top of the `ggplot2` theme system instead of
  editing text grobs: the requested values go into `theme(text=)`, and — because
  layer text does not follow the plot theme — into the layer parameters of text
  geoms such as `geom_text()` and `ggtree::geom_tiplab()`. Theme elements that
  already carry their own values, which would otherwise block the inheritance
  from `theme(text=)`, are updated as well, while aesthetics already mapped with
  `aes()` are left alone so that their legend is not dropped. It returns the
  modified plot rather than drawing a gtable as a side effect, so the result can
  still be extended with `+`; elements sized with `rel()` keep their relative
  size, `size` is in points like `element_text(size=)`, and the font family is
  left untouched unless `family` is supplied. Note that rendered sizes differ
  from previous versions, which multiplied `size` by `.pt`, and that
  `set_font(p, color = "red")` no longer overwrites every serif label
  (2026-10-06, Tue)
+ fix `%<+%` silently returning an empty data frame when the plot data has no
  `node` column; the join result is now only reordered by `node` when that column
  is actually present (2026-10-06, Tue)

# ggfun 0.2.1

+ improve performance of `geom_segment_c()` and `set_font()`; `geom_segment_c()` now supports `nsplit` to control segment expansion (2026-07-02, Thu)
+ fix `geom_segment_c()` for vertical and reversed segments and remove deprecated `aes_string()` usage (2026-07-01, Wed)
+ fix `element_blinds()` grob construction when `id.lengths` is not supplied (2026-07-01, Wed)
+ improve `%<+%` error message when annotation data is missing and add unit tests (2026-07-01, Wed)
+ update get_aes_var to support the quote of complex expressions (#17,2026-07-01, Wed)
+ `geom_hist()` and `stat_hist()` to produce histogram as `hist()` (2025-07-16, Wed)

# ggfun 0.2.0

+ implement `geom_xspline()` via `grid::xsplineGrob()` (2025-07-12, Sat)

# ggfun 0.1.9

+ S3 method consistency with ggplot2 (v=4.0.0) (2025-06-21, Sat, #15, #16)
+ import `ggplot2::facet_grid()` (2025-03-17, Mon)

# ggfun 0.1.8

+ `get_aes_var()` compatible with rlang syntax, `.data[[var]]` and `.data$var` (2024-12-03, Tue)

# ggfun 0.1.7

+ `td_filter()`, `td_mutate()` and `td_unnest()` from the 'ggtree' package (2024-10-24, Thu)
+ `%<+%` method for 'ggtangle' object (2024-10-24, Thu)

# ggfun 0.1.6

+ `%<+%` method for 'ggflow' object (2024-08-28, Wed)
+ `geom_scatter_rect()` to draw retangle boxes as scatter points (2024-08-28, Wed)

# ggfun 0.1.5

+ implement the `%<+%` operator as a S3 method (2024-05-26, Sun)
    - mv the `%<+%` operator from 'ggtree' as the `%<+%.ggtree` method
    - implement `%<+%.ggsc` method for `ggsc` object.

# ggfun 0.1.4

+ deprecate `keybox()` as it is not compatible with ggplot2 v3.5.0 and we have better solution by using `element_roundrect()` (2024-01-18, Thu)
+ `theme_noaxis()` to remove both x and y axes (2023-12-22, Fri)

# ggfun 0.1.3

+ `set_point_legend_shape()` to override point shape legend (2023-09-15, Fri)
+ `get_plot_data()` to extract data from a 'gg' plot (2023-09-12, Tue)

# ggfun 0.1.2

+ add R version dependency in DESCRIPTION (2023-08-04, Fri)
+ `get_legend()` function to extract legend of a plot (2023-07-10, Mon)

# ggfun 0.1.1

+ mv `theme_no_margin()` from the 'aplot' package (2023-06-24, Sat)
+ mv `theme_fp()` from the 'ggbreak' package (2023-06-24, Sat)
+ be compatible with R 4.1 (2023-06-21, Wed, #10)

# ggfun 0.1.0

+ remove `theme_stamp()` and implement a better version `theme_blinds()` which internally use `element_blinds()` to draw the strip background (2023-06-20, Tue, #9)
+ `geom_cake()`, `geom_triangle()` and `geom_segment_c()` functions from 'GuangchuangYu/gglayer' (2023-02-10, Fri)
+ `volplot()` function to visualize volcano plot for DEGs (2022-11-29, Tue)
+ `geom_volpoint()` for volcano plot (2022-11-28, Mon)

# ggfun 0.0.9

+ `theme_noxaxis()` (2022-11-21, Mon)

# ggfun 0.0.8

+ compatible with ggplot2 v3.4.0 (2022-11-07, Mon)

# ggfun 0.0.7

+ add `theme_stamp` (2022-08-31, Wed, #6) (remove since v=0.1.0, use `theme_blinds` instead)

# ggfun 0.0.6

+ mv `identify.gg()` from 'ggtree' (2022-04-01, Fri)
+ mv `ggrange()`, `xrange()` and `yrange()` from 'aplot'

# ggfun 0.0.5

+ mv `theme_transparent()` and `theme_nothing()` from the ggimage package (2022-01-20, Thu)

# ggfun 0.0.4

+ mv `ggbreak2ggplot`, `is.ggbreak` and `is.ggtree` from the aplot package (2021-09-16, Thu)
+ `facet_set`: a better implementation of manually setting facet label, which combines `add_facet`, `ggtree::facet_labeller`  and more (2021-09-15, Wed)
+ `add_facet` to add facet label to a ggplot object (2021-09-03, Fri)

# ggfun 0.0.3

+ `element_roundrect` to add round rect background to ggplot legend. Now we can use `theme()` to enable this effect (2021-08-10)

# ggfun 0.0.2

+ mv `gglegend` and `set_font` functions from `yyplot` package (2021-06-30)
+ mv `get_aes_var` from `rvcheck` package

# ggfun 0.0.1

+ `keybox` to add round rect background to ggplot legend (2021-06-29)

